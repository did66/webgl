import React from "react";
import Player from "../../src/components/Player/Player"

// import './Login.css'

export default function PlayerPage(props) {
    return (
      <Player></Player>
    )
}