import { Layout } from 'antd';
import React from 'react';
import Navbar from '../components/Navbar/Navbar';
// import "../components/Main/global.css"
import Main from '../components/Main/Main';
const { Footer, Sider, Content } = Layout;



export default function MainPage(params) {

  return (
     <Main></Main>
  )
  
}