const baseUrl = "http://10.15.88.38:5008/api";

export default {
  baseUrl: baseUrl,
};
