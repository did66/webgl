export default class User {
    constructor(
      avatar,
      email,
      role,
      token,
      user_id,
      username
       
    ) {
        this.avatar = avatar;
        this.email = email;
        this.role = role;
        this.token = token;
        this.user_id = user_id;
        this.username = username;
    }
}


